# vast-dataengine — Resource Requirements

This document lists the CPU and memory each workload deployed by the
`vast-dataengine` umbrella chart asks for at install time, so a cluster
operator can size a node pool. The numbers below are the chart defaults
(`values.yaml`) — every entry can be overridden through Helm values.

> **Profiles.** The chart ships two ready-made overlays for non-production
> targets: `profiles/kind.yaml` (small kind clusters with bitnami/postgresql)
> and `profiles/lb.yaml` (CI lb-test runs against a real VAST cluster). Both
> shrink the workloads below; see "Test profiles" at the end.

## Per-workload, default values

| Workload | Replicas | CPU req | CPU lim | Mem req | Mem lim | Override key |
|---|--:|--:|--:|--:|--:|---|
| controller-manager | 1 | 10m | 500m | 64Mi | 128Mi | `controller-manager.controllerManager.container.resources` |
| collector | 2–10 (HPA) | 500m | 2 | 512Mi | 1Gi | `collector.collector.container.resources` |
| traces-aggregator | 1 | 250m | 1 | 512Mi | 1Gi | `collector.tracesAggregator.container.resources` |
| fluentbit sidecar (opt-in) | with collector | 50m | 100m | 50Mi | 100Mi | hardcoded¹ |
| knative-operator (operator) | 1 | 100m | 1000m | 100Mi | 1000Mi | `knative.knativeOperator.operator.resources` |
| knative-operator (webhook) | 1 | 100m | 500m | 100Mi | 500Mi | `knative.knativeOperator.webhook.resources` |
| activator (KnativeServing) | 3 | 300m | 1 | 500Mi | 2Gi | `knative.knative.serving.workloads[name=activator]` |
| 3scale-kourier-gateway | 3 | 1 | 2 | 500Mi | 2Gi | `knative.knative.serving.workloads[name=3scale-kourier-gateway]` |
| kafka-broker-dispatcher | 1 (per broker) | — | — | 700Mi | 1Gi | `knative.vast.serverless.knative.kafkaBrokerDispatcher.resources` (memory only) |
| kafka-broker-receiver | 1 (per broker) | — | — | 450Mi | 1Gi | `knative.vast.serverless.knative.kafkaBrokerReceiver.resources` (memory only) |
| serving-default-domain (Job) | transient | 100m | 1000m | 100Mi | 1000Mi | hardcoded¹ |
| pre-install / post-install / pre-delete (Jobs) | transient | 50m | 200m | 64Mi | 128Mi | hardcoded¹ |

¹ These workloads still hardcode resources in the templates; they're
short-lived (Jobs / sidecar) so it hasn't blocked anything in practice.
Track ORION-318880 for parametrising them.

## Aggregate minimum (sum of `requests`, default values)

These are the numbers a node pool must satisfy for **all pods to schedule**
on a real-VAST install. Sums use the lower bound of each HPA range.

```
Sum of requests          ≈ 5.4 CPU,  4.9 GiB
Sum of limits            ≈ 11 CPU,  15 GiB
```

Breakdown of the request column:

```
controller-manager           1 × 0.01 CPU + 64 MiB    = 0.01 CPU, 64 MiB
collector (HPA min=2)        2 × 0.50 CPU + 512 MiB   = 1.00 CPU, 1024 MiB
traces-aggregator            1 × 0.25 CPU + 512 MiB   = 0.25 CPU, 512 MiB
knative-operator             1 × 0.10 CPU + 100 MiB   = 0.10 CPU, 100 MiB
knative-webhook              1 × 0.10 CPU + 100 MiB   = 0.10 CPU, 100 MiB
activator                    3 × 0.30 CPU + 500 MiB   = 0.90 CPU, 1500 MiB
3scale-kourier-gateway       3 × 1.00 CPU + 500 MiB   = 3.00 CPU, 1500 MiB
kafka-broker-dispatcher      1 × (no CPU req) + 700M  =        ~ 700 MiB
kafka-broker-receiver        1 × (no CPU req) + 450M  =        ~ 450 MiB
                                                       --------------------
total                                                 ≈ 5.4 CPU, ≈ 4.9 GiB
```

To this you must add the **knative-operator's own KnativeServing /
KnativeEventing controllers** (controller, webhook, autoscaler,
autoscaler-hpa, net-kourier-controller, kafka-controller,
kafka-source-dispatcher, …). The knative-operator schedules them with its
upstream defaults — typically `100m / 100Mi` per pod, ~10 pods total → an
extra **~1 CPU / ~1 GiB**.

User-function pods (per pipeline, deployed at runtime) are sized by the
Knative Serving autoscaler from your `--user-function-pod` template and
are **not** counted above.

### Recommended node-pool sizing

| Mode | Min nodes | Per-node ask |
|---|---|---|
| Single-node trial / lab | 1 | 12 CPU / 12 GiB |
| Production (HA, room to grow) | 3 | 8 CPU / 8 GiB each — 24 CPU / 24 GiB pool |

If your cluster has the default `BestEffort` QoS (no requests set),
allow at least **20 GiB free RAM** to absorb the limits column on a single
node — Knative serving + kafka brokers are the heaviest tenants.

## Tuning knobs

```yaml
# Smaller collector (cheap dev cluster)
collector:
  collector:
    container:
      resources:
        limits:   { cpu: 250m, memory: 256Mi }
        requests: { cpu: 100m, memory: 128Mi }
    autoscaling:
      minReplicas: 1
      maxReplicas: 2

# Smaller aggregator
collector:
  tracesAggregator:
    container:
      resources:
        limits:   { cpu: 500m, memory: 512Mi }
        requests: { cpu: 100m, memory: 128Mi }

# Single-replica activator + kourier-gateway (ship one user pipeline)
knative:
  knative:
    serving:
      workloads:
        - name: activator
          replicas: 1
        - name: 3scale-kourier-gateway
          replicas: 1
```

## Test profiles

The chart ships two overlay files used by our own automated tests; they
are the smallest configurations we routinely validate.

### `profiles/lb.yaml` — CI lb-tests against a real VAST cluster

```
controller-manager   replicas:1, default resources
collector            replicas:1 (HPA 1–2), cpu 100m–250m, mem 128Mi–256Mi
traces-aggregator    cpu 100m–500m, mem 128Mi–512Mi
activator            replicas:1
3scale-kourier       replicas:1
```

Aggregate request floor: **≈ 1.5 CPU, ≈ 1.5 GiB** (excluding knative
serving controllers).

### `profiles/kind.yaml` — local kind cluster (bitnami/postgresql)

Identical to `profiles/lb.yaml` plus:

  - `kind-registry:5000/...` image repos (preloaded by `task k8s:deploy`).
  - `collector.collector.container.env.VAST_DB_MODE=postgres` — tells the
    collector to use the postgres provider against the local
    bitnami/postgresql release deployed by `task postgres`. Do **not**
    enable this against a real VAST cluster; the postgres-compatible
    interface is on a different VIP and psycopg2 will fail SSL
    negotiation against the HTTP endpoint.
