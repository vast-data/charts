{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Get the namespace to use with priority order:
1. namespace (chart-specific override)
2. global.namespace (umbrella chart override)
3. Explicit --namespace flag (Release.Namespace != "default")
4. "vast-dataengine" (VAST Data default)
5. Release.Namespace fallback
*/}}
{{- define "chart.namespace" -}}
{{- if .Values.namespace }}
{{- .Values.namespace }}
{{- else if .Values.global.namespace }}
{{- .Values.global.namespace }}
{{- else if and .Release.Namespace (ne .Release.Namespace "default") }}
{{- .Release.Namespace }}
{{- else if eq .Release.Namespace "default" }}
{{- "vast-dataengine" }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Chart name.
*/}}
{{- define "chart.name" -}}
{{- if .Values.nameOverride }}
{{- .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else if .Chart.Name }}
{{- .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- "vast-dataengine" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "chart.labels" -}}
vast-app: {{ include "chart.name" . }}
helm.sh/chart: {{ include "chart.chart" . }}
{{ include "chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "hooks.kubectl.image" -}}
{{- $registry := default .Values.global.registry .Values.hooks.kubectl.registry -}}
{{- if $registry -}}
{{ $registry }}/{{ .Values.hooks.kubectl.repository }}:{{ .Values.hooks.kubectl.tag }}
{{- else -}}
{{ .Values.hooks.kubectl.repository }}:{{ .Values.hooks.kubectl.tag }}
{{- end -}}
{{- end }}
