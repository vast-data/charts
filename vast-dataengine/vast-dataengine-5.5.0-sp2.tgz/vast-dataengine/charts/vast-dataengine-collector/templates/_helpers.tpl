{{/*
Expand the name of the chart.
*/}}
{{- define "chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Get the namespace to use with priority order:
1. namespace (chart-specific override)
2. global.namespace (umbrella chart override)
3. Explicit --namespace flag (Release.Namespace != "default")
4. "vast-dataengine" (VAST Data default)
5. Release.Namespace fallback
*/}}
{{- define "chart.namespace" -}}
{{- if .Values.namespace }}
{{- .Values.namespace }}
{{- else if .Values.global.namespace }}
{{- .Values.global.namespace }}
{{- else if and .Release.Namespace (ne .Release.Namespace "default") }}
{{- .Release.Namespace }}
{{- else if eq .Release.Namespace "default" }}
{{- "vast-dataengine" }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Override chart.labels to include vast-app label.
This chart has an additional vast-app label before the standard labels.
*/}}
{{- define "chart.labels" -}}
vast-app: {{ include "chart.name" . }}
helm.sh/chart: {{ include "chart.chart" . }}
{{ include "chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Container image with registry support.
Priority: global.registry/image.repository or image.repository
Tag priority: global.image.tag > image.tag > Chart.AppVersion
*/}}
{{- define "collector.image" -}}
{{- $repository := .Values.image.repository -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{- if .Values.global -}}
  {{- if .Values.global.image -}}
    {{- if .Values.global.image.tag -}}
      {{- $tag = .Values.global.image.tag -}}
    {{- end -}}
  {{- end -}}
  {{- if .Values.global.registry -}}
    {{- $repository = printf "%s/%s" .Values.global.registry .Values.image.repository -}}
  {{- end -}}
{{- end -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}

{{/*
Image pull policy.
Priority: global.image.pullPolicy > image.pullPolicy > IfNotPresent
*/}}
{{- define "collector.imagePullPolicy" -}}
{{- if and .Values.global .Values.global.image .Values.global.image.pullPolicy -}}
{{- .Values.global.image.pullPolicy -}}
{{- else if .Values.image.pullPolicy -}}
{{- .Values.image.pullPolicy -}}
{{- else -}}
{{- "IfNotPresent" -}}
{{- end -}}
{{- end -}}

{{/*
Image pull secret.
*/}}
{{- define "collector.imagePullSecret" -}}
{{- if and .Values.global .Values.global.image .Values.global.image.pullSecret -}}
{{- .Values.global.image.pullSecret -}}
{{- end -}}
{{- end -}}
