# vast-dataengine-collector

A Kubernetes collector for VAST Data infrastructure monitoring and log aggregation

![Version: 5.5.0-dev.9e122e6c](https://img.shields.io/badge/Version-5.5.0--dev.9e122e6c-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v5.5.0-dev.9e122e6c](https://img.shields.io/badge/AppVersion-v5.5.0--dev.9e122e6c-informational?style=flat-square)

## Prerequisites

- Kubernetes
- Helm 3.x

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| VAST Data Compute Team | <compute-engine-team@vastdata.com> |  |

## Installation

```bash
helm install vast-dataengine-collector ./vast-dataengine-collector
```

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://kubernetes-sigs.github.io/metrics-server/ | metrics-server | 3.12.1 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| collector.affinity | object | `{}` | Affinity rules |
| collector.autoscaling.behavior | object | `{"scaleDown":{"percentPolicy":50,"periodSeconds":60,"stabilizationWindowSeconds":300},"scaleUp":{"percentPolicy":100,"periodSeconds":60,"stabilizationWindowSeconds":60}}` | Autoscaling behavior configuration |
| collector.autoscaling.enabled | bool | `true` | Enable autoscaling |
| collector.autoscaling.maxReplicas | int | `10` | Maximum number of replicas |
| collector.autoscaling.minReplicas | int | `2` | Minimum number of replicas. The collector is stateless and the HPA scales it on memory/CPU, so a small floor is fine for typical installs — operators with heavy ingest should bump this up. |
| collector.autoscaling.targetCPUUtilizationPercentage | int | `80` | Target CPU utilization percentage |
| collector.autoscaling.targetMemoryUtilizationPercentage | int | `75` | Target memory utilization percentage |
| collector.clusterRoleName | string | `"vast-collector"` | Cluster role name |
| collector.configSecretName | string | `"vast-telemetries-collector-config"` | Config secret name for collector configuration. Must match provisioning's `VAST_COLLECTOR_CONFIG_SECRET_NAME` constant — the provisioning service writes the per-tenant collector config into a secret of this exact name and the collector + aggregator deployments mount it as a Secret volume. |
| collector.container.args | list | `[]` | Additional command arguments |
| collector.container.command | list | `["telemetries_collector_service"]` | Container command |
| collector.container.livenessProbe | object | `{"httpGet":{"path":"/healthz","port":8080},"initialDelaySeconds":15,"periodSeconds":20}` | Liveness probe configuration |
| collector.container.readinessProbe | object | `{"failureThreshold":10,"httpGet":{"path":"/readyz","port":8080},"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":3,"timeoutSeconds":10}` | Readiness probe configuration |
| collector.container.resources | object | `{"limits":{"cpu":2,"memory":"1Gi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource requests and limits |
| collector.container.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` | Container security context |
| collector.env | object | `{"WORKERS_AMOUNT":"4"}` | Additional environment variables |
| collector.name | string | `"vast-collector"` | Collector deployment name |
| collector.nodeSelector | object | `{}` | Node selector |
| collector.podAnnotations | object | `{}` | Pod annotations |
| collector.podLabels | object | `{}` | Pod labels |
| collector.port | int | `8080` | Service port |
| collector.replicas | int | `2` | Number of replicas (initial; ignored when autoscaling is enabled below) |
| collector.securityContext | object | `{"runAsNonRoot":true,"runAsUser":65534,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context |
| collector.serviceAccountName | string | `"vast-collector"` | Service account name |
| collector.terminationGracePeriodSeconds | int | `10` | Termination grace period in seconds |
| collector.tolerations | list | `[]` | Tolerations |
| collector.topologySpreadConstraints | list | `[{"maxSkew":2,"topologyKey":"kubernetes.io/hostname","whenUnsatisfiable":"ScheduleAnyway"}]` | Pod topology spread constraints. Best-effort spread of collector pods across nodes; pods still schedule if no spread is achievable, and the descheduler can rebalance later. Mirrors the legacy vast-telemetries-collector chart default. |
| commonLabels | object | `{}` | Common labels applied to all resources |
| fullnameOverride | string | `""` | Override the full name of the chart |
| global.image.pullPolicy | string | `""` | Global image pull policy override |
| global.image.pullSecret | string | `""` | Image pull secret name |
| global.image.tag | string | `""` | Global image tag override |
| global.namespace | string | `""` | Global namespace override (useful when used as a subchart) |
| global.registry | string | `""` | Global registry prefix (prepended to image.repository, e.g. "my-registry.io") |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.repository | string | `"vastdataorg/vast-dataengine-collector"` | Container image repository |
| image.tag | string | `""` | Overrides the image tag (default is the chart appVersion) |
| imagePullSecrets | list | `[]` | Image pull secrets for private registries |
| metrics-server.enabled | bool | `false` | Enable metrics-server subchart |
| nameOverride | string | `""` | Override the name of the chart (controls suffix in resource names) |
| namespace | string | `""` | Default namespace (if empty, uses "vast-dataengine" or kubectl context default) |
| runtimeConfig.filename | string | `"runtime-config.yaml"` | Runtime config filename |
| runtimeConfig.name | string | `"runtime-configmap"` | ConfigMap name for runtime configuration |
| runtimeConfig.useFluentBit | bool | `false` | Enable FluentBit sidecar |
