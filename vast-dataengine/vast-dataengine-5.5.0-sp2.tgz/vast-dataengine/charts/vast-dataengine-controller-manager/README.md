# vast-dataengine-controller-manager

VAST DataEngine controller-manager for managing pipelines, tenants, and Kafka brokers

![Version: 5.5.0-dev.74b53a39](https://img.shields.io/badge/Version-5.5.0--dev.74b53a39-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v5.5.0-dev.74b53a39](https://img.shields.io/badge/AppVersion-v5.5.0--dev.74b53a39-informational?style=flat-square)

## Prerequisites

- Kubernetes
- Helm 3.x

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| VAST Data Compute Team | <compute-engine-team@vastdata.com> |  |

## Installation

```bash
helm install vast-dataengine-controller-manager ./vast-dataengine-controller-manager
```

## Namespace scoping

`namespaceWatch.restrict` (default `false`): cluster-wide informer cache and namespaced RBAC rules on the ClusterRole.

When `namespaceWatch.restrict` is `true`, `namespaceWatch.watchNamespaces` drives `--watch-namespaces` and per-namespace Roles (VastPipeline, Knative, etc.). Defaults include `vast-dataengine` and Knative system namespaces; release and chart namespace are always included. Callers must pre-create listed namespaces before install.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| certmanager.enable | bool | `false` | Enable cert-manager for TLS certificates |
| collector.service.name | string | `""` | Collector service name override. Leave empty to derive it from the release name (mirrors the vast-dataengine-collector subchart's "<chart.fullname>-service"). |
| collector.service.port | int | `8080` | Collector service port |
| collector.service.scheme | string | `"http"` | Collector service scheme |
| controllerManager.affinity | object | `{}` | Affinity rules |
| controllerManager.container.args | list | `["controller-manager","--metrics-bind-address=:8443","--health-probe-bind-address=:8081","--collector-endpoint={{.Values.collector.service.scheme}}://{{.Values.collector.service.name}}.{{.Values.collector.service.namespace | default \"vast-dataengine\" }}:{{.Values.collector.service.port}}"]` | Command arguments for the controller manager |
| controllerManager.container.extraArgs | list | `[]` | Additional command line arguments |
| controllerManager.container.livenessProbe | object | `{"httpGet":{"path":"/healthz","port":8081},"initialDelaySeconds":15,"periodSeconds":20}` | Liveness probe configuration |
| controllerManager.container.readinessProbe | object | `{"httpGet":{"path":"/readyz","port":8081},"initialDelaySeconds":5,"periodSeconds":10}` | Readiness probe configuration |
| controllerManager.container.resources | object | `{"limits":{"cpu":"500m","memory":"128Mi"},"requests":{"cpu":"10m","memory":"64Mi"}}` | Resource requests and limits |
| controllerManager.container.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` | Container security context |
| controllerManager.env | list | `[]` | Additional environment variables |
| controllerManager.extraVolumeMounts | list | `[]` | Additional volume mounts |
| controllerManager.extraVolumes | list | `[]` | Additional volumes |
| controllerManager.nodeSelector | object | `{}` | Node selector |
| controllerManager.podAnnotations | object | `{}` | Pod annotations |
| controllerManager.podLabels | object | `{}` | Pod labels |
| controllerManager.replicas | int | `1` | Number of replicas |
| controllerManager.securityContext | object | `{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context |
| controllerManager.serviceAccountName | string | `"vast-dataengine-controller-manager"` | Service account name |
| controllerManager.terminationGracePeriodSeconds | int | `10` | Termination grace period in seconds |
| controllerManager.tolerations | list | `[]` | Tolerations |
| crd.enable | bool | `true` | Install CRDs with the chart |
| crd.keep | bool | `true` | Keep CRDs when the chart is uninstalled |
| fullnameOverride | string | `""` | Override the full name of the chart |
| global.image.pullPolicy | string | `""` | Global image pull policy override |
| global.image.pullSecret | string | `""` | Image pull secret name |
| global.image.tag | string | `""` | Global image tag override |
| global.namespace | string | `""` | Global namespace override (useful when used as a subchart) |
| global.registry | string | `""` | Global registry prefix (prepended to image.repository, e.g. "my-registry.io") |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.repository | string | `"vastdataorg/vast-dataengine-controller-manager"` | Container image repository |
| image.tag | string | `""` | Overrides the image tag (default is the chart appVersion) |
| imagePullSecrets | list | `[]` | Image pull secrets for private registries |
| metrics.enable | bool | `true` | Enable metrics endpoint |
| nameOverride | string | `""` | Override the name of the chart (controls suffix in resource names) |
| namespace | string | `""` | Default namespace (if empty, uses "vast-dataengine" or kubectl context default) |
| namespaceAnnotations | object | `{}` | Additional annotations for the namespace |
| namespaceCreate | bool | `false` | Create namespace if it doesn't exist |
| networkPolicy.enable | bool | `false` | Enable NetworkPolicies |
| prometheus.enable | bool | `false` | Enable ServiceMonitor for Prometheus Operator |
| rbac.enable | bool | `true` | Create RBAC resources |
