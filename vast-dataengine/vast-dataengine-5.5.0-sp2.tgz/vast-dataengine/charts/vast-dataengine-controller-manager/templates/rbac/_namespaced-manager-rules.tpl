{{/*
RBAC rules for pipeline/Knative reconciliation in a single namespace.
Used on per-namespace Roles (restrict: true) and on ClusterRole (restrict: false).
*/}}
{{- define "vast-dataengine-controller-manager.namespacedManagerRules" -}}
  # VAST namespaced CRs (VastPipeline, VastKafkaBroker)
  - apiGroups:
      - vast.vastdata.com
    resources:
      - vastpipelines
      - vastkafkabrokers
    verbs:
      - create
      - delete
      - get
      - list
      - patch
      - update
      - watch
  - apiGroups:
      - vast.vastdata.com
    resources:
      - vastpipelines/status
      - vastkafkabrokers/status
    verbs:
      - get
      - patch
      - update
  - apiGroups:
      - vast.vastdata.com
    resources:
      - vastpipelines/finalizers
      - vastkafkabrokers/finalizers
    verbs:
      - update

  # Knative Eventing (Brokers, Triggers)
  - apiGroups:
      - eventing.knative.dev
    resources:
      - brokers
      - triggers
    verbs:
      - create
      - delete
      - get
      - list
      - patch
      - update
      - watch

  # Knative Serving (Services)
  - apiGroups:
      - serving.knative.dev
    resources:
      - services
    verbs:
      - create
      - delete
      - get
      - list
      - patch
      - update
      - watch

  # Knative Sources (SinkBindings)
  - apiGroups:
      - sources.knative.dev
    resources:
      - sinkbindings
    verbs:
      - create
      - delete
      - get
      - list
      - patch
      - update
      - watch

  # Knative Kafka ConsumerGroups (required by knativeconsumergroup reconciler)
  - apiGroups:
      - internal.kafka.eventing.knative.dev
    resources:
      - consumergroups
    verbs:
      - get
      - list
      - watch
      - patch
      - update

  # Workload resources (StatefulSets for pipeline components)
  - apiGroups:
      - apps
    resources:
      - statefulsets
    verbs:
      - create
      - delete
      - get
      - list
      - patch
      - update
      - watch

  # Core resources - ConfigMaps
  - apiGroups:
      - ""
    resources:
      - configmaps
    verbs:
      - create
      - delete
      - get
      - list
      - patch
      - update
      - watch

  # Core resources - Secrets (read-only)
  - apiGroups:
      - ""
    resources:
      - secrets
    verbs:
      - get
      - list
      - watch

  # Core resources - Events
  - apiGroups:
      - ""
    resources:
      - events
    verbs:
      - create
      - patch

  # VastDataEngine CRs (required by vastdataengine-version reconciler)
  - apiGroups:
      - operator.vastdata.com
    resources:
      - vastdataengines
    verbs:
      - create
      - get
      - list
      - watch
  - apiGroups:
      - operator.vastdata.com
    resources:
      - vastdataengines/status
    verbs:
      - get
      - patch
      - update

  # Leader election leases in watch namespaces
  - apiGroups:
      - coordination.k8s.io
    resources:
      - leases
    verbs:
      - create
      - delete
      - get
      - list
      - patch
      - update
      - watch
{{- end -}}
