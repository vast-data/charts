{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Get the namespace to use with priority order:
1. namespace (chart-specific override)
2. global.namespace (umbrella chart override)
3. Explicit --namespace flag (Release.Namespace != "default")
4. "vast-dataengine" (VAST Data default)
5. Release.Namespace fallback
*/}}
{{- define "chart.namespace" -}}
{{- if .Values.namespace }}
{{- .Values.namespace }}
{{- else if .Values.global.namespace }}
{{- .Values.global.namespace }}
{{- else if and .Release.Namespace (ne .Release.Namespace "default") }}
{{- .Release.Namespace }}
{{- else if eq .Release.Namespace "default" }}
{{- "vast-dataengine" }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Override chart.name to match existing behavior.
The controller-manager chart uses nameOverride with a fallback to Chart.Name,
then falls back to "controller-manager" as a hardcoded default.
*/}}
{{- define "chart.name" -}}
{{- if .Values.nameOverride }}
{{- .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else if .Chart.Name }}
{{- .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- "controller-manager" }}
{{- end }}
{{- end }}

{{/*
Override chart.labels to match existing label format.
This chart uses Chart.Version (quoted) for helm.sh/chart instead of chart-name-version.
*/}}
{{- define "chart.labels" -}}
{{- if .Chart.AppVersion -}}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- if .Chart.Version }}
helm.sh/chart: {{ .Chart.Version | quote }}
{{- end }}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "chart.hasMutatingWebhooks" -}}
{{- $hasMutating := false }}
{{- range . }}
  {{- if eq .type "mutating" }}
    $hasMutating = true }}{{- end }}
{{- end }}
{{ $hasMutating }}}}{{- end }}


{{- define "chart.hasValidatingWebhooks" -}}
{{- $hasValidating := false }}
{{- range . }}
  {{- if eq .type "validating" }}
    $hasValidating = true }}{{- end }}
{{- end }}
{{ $hasValidating }}}}{{- end }}


{{/*
Container image with registry support.
Priority: global.registry/image.repository or image.repository
Tag priority: global.image.tag > image.tag > Chart.AppVersion
*/}}
{{- define "vast-controller-manager.image" -}}
{{- $repository := .Values.image.repository -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{- if .Values.global -}}
  {{- if .Values.global.image -}}
    {{- if .Values.global.image.tag -}}
      {{- $tag = .Values.global.image.tag -}}
    {{- end -}}
  {{- end -}}
  {{- if .Values.global.registry -}}
    {{- $repository = printf "%s/%s" .Values.global.registry .Values.image.repository -}}
  {{- end -}}
{{- end -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}

{{/*
Image pull policy.
Priority: global.image.pullPolicy > image.pullPolicy > IfNotPresent
*/}}
{{- define "vast-controller-manager.imagePullPolicy" -}}
{{- if and .Values.global .Values.global.image .Values.global.image.pullPolicy -}}
{{- .Values.global.image.pullPolicy -}}
{{- else if .Values.image.pullPolicy -}}
{{- .Values.image.pullPolicy -}}
{{- else -}}
{{- "IfNotPresent" -}}
{{- end -}}
{{- end -}}

{{/*
Image pull secret.
*/}}
{{- define "vast-controller-manager.imagePullSecret" -}}
{{- if and .Values.global .Values.global.image .Values.global.image.pullSecret -}}
{{- .Values.global.image.pullSecret -}}
{{- end -}}
{{- end -}}

{{/*
Webhook image with registry support.
Same resolution as main image but allows webhook-specific repository/tag overrides.
Priority: global.registry prefix > webhook override > image default
Tag: global.image.tag > webhook override > image.tag > Chart.AppVersion
*/}}
{{- define "vast-controller-manager.webhook.image" -}}
{{- $repository := .Values.image.repository -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{- if .Values.webhook -}}
  {{- if .Values.webhook.container -}}
    {{- if .Values.webhook.container.image -}}
      {{- if .Values.webhook.container.image.repository -}}
        {{- $repository = .Values.webhook.container.image.repository -}}
      {{- end -}}
      {{- if .Values.webhook.container.image.tag -}}
        {{- $tag = .Values.webhook.container.image.tag -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if .Values.global -}}
  {{- if .Values.global.image -}}
    {{- if .Values.global.image.tag -}}
      {{- $tag = .Values.global.image.tag -}}
    {{- end -}}
  {{- end -}}
  {{- if .Values.global.registry -}}
    {{- $repository = printf "%s/%s" .Values.global.registry $repository -}}
  {{- end -}}
{{- end -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}

{{/*
Convert a map of labels to a comma-separated string of key=value pairs.
Example: {"foo": "bar", "baz": "qux"} -> "baz=qux,foo=bar"
*/}}
{{- define "chart.labelsToString" -}}
{{- $pairs := list -}}
{{- range $k, $v := . -}}
{{- $pairs = append $pairs (printf "%s=%s" $k $v) -}}
{{- end -}}
{{- join "," $pairs -}}
{{- end -}}

{{/*
Fail if namespace list is empty or contains blank entries.
*/}}
{{- define "vast-dataengine-controller-manager.validateNamespaceList" -}}
{{- $name := .name -}}
{{- $list := .list -}}
{{- if not $list -}}
{{- fail (printf "%s is required and cannot be empty" $name) -}}
{{- end -}}
{{- range $list -}}
{{- if not (trim .) -}}
{{- fail (printf "%s must not contain empty namespace names" $name) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Effective watch namespaces when restrict is true: values plus release/chart namespace.
*/}}
{{- define "vast-dataengine-controller-manager.effectiveWatchNamespaces" -}}
{{- $chartNS := include "chart.namespace" . -}}
{{- $watch := .Values.namespaceWatch.watchNamespaces | default list -}}
{{- $ns := concat $watch (list .Release.Namespace $chartNS) | compact | uniq -}}
{{- $ns | toYaml -}}
{{- end -}}

{{/*
Collector Service name used to build the operator's --collector-endpoint.

The vast-dataengine-collector subchart names its Service
"<chart.fullname>-service". Because the subchart is pulled in under the fixed
alias "collector", Helm sets the subchart's effective .Chart.Name to the alias
"collector", so chart.fullname resolves to "<release>-collector" and the Service
to "<release>-collector-service" (e.g. "vast-internal-k8s-collector-service" for
the vast-internal-k8s umbrella vs "vast-dataengine-collector-service" for a
plain vast-dataengine release). This helper mirrors that derivation (name
"collector") so the injected OTLP endpoint always tracks the collector Service
regardless of the release name (ORION-384782).

An explicit .Values.collector.service.name still wins as an override knob.
*/}}
{{- define "vast-dataengine-controller-manager.collectorServiceName" -}}
{{- if .Values.collector.service.name -}}
{{- .Values.collector.service.name -}}
{{- else -}}
{{- $name := "collector" -}}
{{- $fullname := "" -}}
{{- if contains $name .Release.Name -}}
{{- $fullname = .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $fullname = printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- printf "%s-service" $fullname -}}
{{- end -}}
{{- end -}}
