{{- define "namespace.labels" -}}
{{- range $k, $v := .Values.namespaceLabels }}
{{ tpl $k . }}: {{ tpl (toString $v) . }}
{{- end -}}
{{- end -}}

{{- define "knative-eventing.namespaceLabels" -}}
{{- include "namespace.labels" . -}}
{{ range $k, $v := .Values.knative.eventing.namespace.labels }}
{{ tpl $k . }}: {{- tpl (toString $v) . -}}
{{- end -}}
{{- end -}}

{{- define "knative-eventing.namespace" -}}
{{- .Values.knative.eventing.namespace.name | default "knative-eventing" }}
{{- end -}}

{{- define "knative-eventing.kafkaBrokerDataPlaneConfigMap" -}}
{{- .Values.knative.eventing.kafkaBrokerDataPlaneConfigMap | default "config-kafka-broker-data-plane" }}
{{- end -}}

{{- define "knative-serving.namespace" -}}
{{- .Values.knative.serving.namespace.name | default "knative-serving" }}
{{- end -}}

{{- define "knative-serving.namespaceLabels" -}}
{{- include "namespace.labels" . -}}
{{ range $k, $v := .Values.knative.serving.namespace.labels }}
{{ tpl $k . }}: {{- tpl (toString $v) . -}}
{{- end -}}
{{- end -}}

{{- define "knative-operator.namespaceLabels" -}}
{{- include "namespace.labels" . -}}
{{ range $k, $v := .Values.knativeOperator.namespace.labels }}
{{ tpl $k . }}: {{- tpl (toString $v) . -}}
{{- end -}}
{{- end -}}

{{/* Return the Knative version. Given format can be "1.17.1" or "v1.17.1" */}}
{{- define "knative.version" -}}
{{- .Values.knative.version | replace "v" "" }}
{{- end -}}

{{/* Return the Knative Operator version. Given format can be "1.20.0" or "v1.20.0" */}}
{{- define "knative-operator.version" -}}
{{- $version := include "knative.version" . }}
{{- if .Values.knativeOperator.version }}
{{- $version = .Values.knativeOperator.version | replace "v" "" }}
{{- end }}
{{- $version }}
{{- end }}

{{/* Return the Knative Serving version. Default to the Knative version if not set */}}
{{- define "knative-serving.version" -}}
{{- $version := include "knative.version" . }}
{{- if .Values.knative.serving.version }}
{{- $version = .Values.knative.serving.version | replace "v" "" }}
{{- end }}
{{- $version }}
{{- end -}}

{{/*
Render the KnativeServing `registry.override` map, resolving each value through
`tpl` so image strings may reference helm helpers
(e.g. `{{ include "knative-serving.version" . }}`).
Usage: {{ include "knative-serving.registry.override" $ | nindent 6 }}
Note: Only call this when .Values.knative.serving.registry.override exists.
*/}}
{{- define "knative-serving.registry.override" -}}
{{- $out := dict -}}
{{- range $k, $v := .Values.knative.serving.registry.override -}}
{{- $_ := set $out $k (tpl (toString $v) $) -}}
{{- end -}}
{{- $out | toYaml -}}
{{- end -}}

{{/* Return the Knative Eventing version. Default to the Knative version if not set */}}
{{- define "knative-eventing.version" -}}
{{- $version := include "knative.version" . }}
{{- if .Values.knative.eventing.version }}
{{- $version = .Values.knative.eventing.version | replace "v" "" }}
{{- end }}
{{- $version }}
{{- end -}}

{{- define "knative.operator.image" -}}
{{- if .Values.knativeOperator.operator.image }}
{{- tpl .Values.knativeOperator.operator.image . }}
{{- else }}
{{- printf "gcr.io/knative-releases/knative.dev/operator/cmd/operator:v%s" (include "knative-operator.version" .) }}
{{- end }}
{{- end -}}

{{- define "knative.operator.webhook.image" -}}
{{- if .Values.knativeOperator.webhook.image -}}
{{- tpl .Values.knativeOperator.webhook.image . -}}
{{- else }}
{{- printf "gcr.io/knative-releases/knative.dev/operator/cmd/webhook:v%s" (include "knative-operator.version" .) }}
{{- end -}}
{{- end -}}


{{/* Create a default fully qualified app name */}}
{{- define "vast-knative.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/* Common labels */}}
{{- define "vast-knative.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "vast-knative.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/* Selector labels */}}
{{- define "vast-knative.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Generate a hostname topology-spread-constraint YAML list item for HA.
Returns empty string if global.defaultAffinity is disabled.
Accepts dict: { appLabel, root }
*/}}
{{- define "vast-knative.hostnameSpreadConstraint" -}}
{{- $da := .root.Values.global.defaultAffinity -}}
{{- if and $da $da.enabled -}}
- maxSkew: 1
  topologyKey: {{ $da.topologyKey | default "kubernetes.io/hostname" }}
  whenUnsatisfiable: ScheduleAnyway
  nodeTaintsPolicy: Honor
  labelSelector:
    matchLabels:
      app: {{ .appLabel }}
{{- end -}}
{{- end -}}

{{/*
Control-plane and legacy master tolerations YAML list.
Callers gate on the appropriate tolerateControlPlane flag before invoking.
*/}}
{{- define "vast-knative.controlPlaneTolerations" -}}
- key: node-role.kubernetes.io/control-plane
  operator: Exists
  effect: NoSchedule
- key: node-role.kubernetes.io/control-plane
  operator: Exists
  effect: PreferNoSchedule
- key: node-role.kubernetes.io/master
  operator: Exists
  effect: NoSchedule
- key: node-role.kubernetes.io/master
  operator: Exists
  effect: PreferNoSchedule
{{- end -}}

{{/*
Inject default topology-spread-constraints and tolerations into workloads list
for Knative operator CRDs. For each workload without explicit
topologySpreadConstraints, adds a hostname-based TSC using the workload name
as the app label. When tolerateControlPlane is enabled, also injects
control-plane tolerations into workloads without explicit tolerations.
Accepts dict: { workloads, root }
*/}}
{{- define "vast-knative.workloadsWithDefaults" -}}
{{- $da := .root.Values.global.defaultAffinity -}}
{{- $result := list -}}
{{- range .workloads -}}
{{- $w := deepCopy . -}}
{{- if and $da $da.enabled -}}
{{- if not (hasKey $w "topologySpreadConstraints") -}}
{{- $tscYaml := include "vast-knative.hostnameSpreadConstraint" (dict "appLabel" .name "root" $.root) -}}
{{- if $tscYaml -}}
{{- $_ := set $w "topologySpreadConstraints" ($tscYaml | fromYamlArray) -}}
{{- end -}}
{{- end -}}
{{- if and $da.tolerateControlPlane (not (hasKey $w "tolerations")) -}}
{{- $tolYaml := include "vast-knative.controlPlaneTolerations" (dict "root" $.root) -}}
{{- if $tolYaml -}}
{{- $_ := set $w "tolerations" ($tolYaml | fromYamlArray) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $result = append $result $w -}}
{{- end -}}
{{- toYaml $result -}}
{{- end -}}

{{/*
Resolve a Kafka data-plane image using the 3-tier fallback:
  1. Explicit per-component override  (.Values.vast.serverless.knative.<valuesKey>.image)
  2. Global registry/repository       (<registry>/<repository>:<tagName>-<eventing version>)
  3. Hardcoded upstream digest         (defaultImage)
Accepts dict: { valuesKey, tagName, defaultImage, root }
Note: The image value supports Helm template expressions (evaluated via tpl).
*/}}
{{- define "eventing-kafka.image" -}}
{{- $comp := dig "vast" "serverless" "knative" .valuesKey nil (.root.Values | toJson | fromJson) -}}
{{- if and $comp $comp.image -}}
{{- tpl $comp.image .root -}}
{{- else if and .root.Values.global.registry .root.Values.global.repository -}}
{{- .root.Values.global.registry }}/{{ .root.Values.global.repository }}:{{ .tagName }}-{{ include "knative-eventing.version" .root -}}
{{- else -}}
{{- .defaultImage -}}
{{- end -}}
{{- end -}}

{{/* Construct the kubectl image for hook jobs */}}
{{- define "hooks.kubectl.image" -}}
{{- $registry := default .Values.global.registry .Values.hooks.kubectl.registry -}}
{{- if $registry -}}
{{ $registry }}/{{ .Values.hooks.kubectl.repository }}:{{ .Values.hooks.kubectl.tag }}
{{- else -}}
{{ .Values.hooks.kubectl.repository }}:{{ .Values.hooks.kubectl.tag }}
{{- end -}}
{{- end -}}
